$(document).ready(function () {
    $("#title").text("Healthcare Chatbot");
});

$(document).ready(function () {
    $('.hidden').hide().fadeIn(1500);
});
