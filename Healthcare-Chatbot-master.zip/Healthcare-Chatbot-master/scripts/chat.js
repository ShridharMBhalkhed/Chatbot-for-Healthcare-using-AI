$(document).ready(function(){
    $("#formButton").click(function(){
        $("#form1").toggle();
    });
});
